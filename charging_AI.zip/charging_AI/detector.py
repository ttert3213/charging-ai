from pathlib import Path
import json
import cv2
from ultralytics import YOLO

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "yolov8n.pt"
SLOTS_PATH = BASE_DIR / "config" / "charging_slots.json"

# COCO class IDs: car=2, bus=5, truck=7.
# В учебном прототипе учитываются автомобили и другие дорожные транспортные средства.
VEHICLE_CLASS_IDS = {2, 5, 7}

class DetectionError(Exception):
    pass

class VehicleDetector:
    def __init__(self, model_path=MODEL_PATH, slots_path=SLOTS_PATH, confidence=0.15):
        self.model_path = Path(model_path)
        self.slots_path = Path(slots_path)
        self.confidence = confidence
        try:
            self.model = YOLO(str(self.model_path))
        except Exception as exc:
            raise DetectionError(
                "Не удалось загрузить YOLOv8. Проверьте установку ultralytics и доступ к сети "
                "при первой загрузке весов yolov8n.pt."
            ) from exc

    def _load_slots(self):
        if not self.slots_path.exists():
            return []
        try:
            data = json.loads(self.slots_path.read_text(encoding="utf-8"))
            return data.get("slots", [])
        except (json.JSONDecodeError, OSError):
            return []

    @staticmethod
    def _inside(point, polygon):
        # Ray casting: проверка попадания центра рамки внутрь полигона места.
        x, y = point
        inside = False
        j = len(polygon) - 1
        for i in range(len(polygon)):
            xi, yi = polygon[i]
            xj, yj = polygon[j]
            intersects = ((yi > y) != (yj > y)) and (
                x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-9) + xi
            )
            if intersects:
                inside = not inside
            j = i
        return inside

    def analyze(self, image_path, output_path):
        image = cv2.imread(str(image_path))
        if image is None:
            raise DetectionError("Не удалось прочитать изображение. Проверьте формат файла.")

        if image.shape[1] > 800:
            image = image[16:591, 133:802]

        height, width = image.shape[:2]
        try:
            prediction = self.model.predict(
                source=image,
                conf=self.confidence,
                classes=sorted(VEHICLE_CLASS_IDS),
		imgsz=640,
                verbose=False
            )[0]
        except Exception as exc:
            raise DetectionError(f"Ошибка выполнения модели: {exc}") from exc

        slots = self._load_slots()
        slot_states = []
        for slot in slots:
            # Координаты в JSON задаются в долях ширины/высоты (0..1).
            polygon = [[int(px * width), int(py * height)] for px, py in slot["polygon"]]
            slot_states.append({
                "id": str(slot["id"]),
                "name": slot.get("name", str(slot["id"])),
                "polygon": polygon,
                "occupied": False,
            })

        confidences = []
        vehicle_count = 0
        for box in prediction.boxes:
            cls_id = int(box.cls[0].item())
            if cls_id not in VEHICLE_CLASS_IDS:
                continue
            x1, y1, x2, y2 = [int(v) for v in box.xyxy[0].tolist()]
            conf = float(box.conf[0].item())
            center = ((x1 + x2) // 2, (y1 + y2) // 2)
            vehicle_count += 1
            confidences.append(conf)

            label = self.model.names.get(cls_id, "vehicle")
            cv2.rectangle(image, (x1, y1), (x2, y2), (40, 190, 90), 2)
            cv2.putText(image, f"{label} {conf:.2f}", (x1, max(20, y1 - 8)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (40, 190, 90), 2)

            for slot_state in slot_states:
                if self._inside(center, slot_state["polygon"]):
                    slot_state["occupied"] = True

        for slot_state in slot_states:
            poly = slot_state["polygon"]
            color = (30, 80, 230) if slot_state["occupied"] else (230, 160, 30)
            import numpy as np
            pts = np.array(poly, dtype="int32").reshape((-1, 1, 2))
            cv2.polylines(image, [pts], True, color, 3)
            caption = f'{slot_state["name"]}: {"занято" if slot_state["occupied"] else "свободно"}'
            anchor = poly[0]
            cv2.putText(image, caption, (anchor[0], max(20, anchor[1] - 7)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        if not cv2.imwrite(str(output_path), image):
            raise DetectionError("Не удалось сохранить обработанное изображение.")

        occupied = sum(1 for item in slot_states if item["occupied"])
        return {
            "vehicle_count": vehicle_count,
            "occupied_slots": occupied,
            "total_slots": len(slot_states),
            "free_slots": max(0, len(slot_states) - occupied),
            "mean_confidence": round(sum(confidences) / len(confidences), 4) if confidences else 0.0,
            "slots": [{"id": s["id"], "name": s["name"], "occupied": s["occupied"]} for s in slot_states],
            "note": "Результат отражает обнаружение транспортных средств и геометрическую занятость заданных зон. Это не подтверждает тип силовой установки и факт подключения кабеля."
        }
