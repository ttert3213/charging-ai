const form = document.getElementById("uploadForm");
const input = document.getElementById("imageInput");
const fileName = document.getElementById("fileName");
const runButton = document.getElementById("runButton");
const errorBox = document.getElementById("errorBox");

input.addEventListener("change", () => {
  fileName.textContent = input.files.length ? input.files[0].name : "Файл не выбран";
  errorBox.hidden = true;
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!input.files.length) return;
  const data = new FormData();
  data.append("image", input.files[0]);
  runButton.disabled = true;
  runButton.innerHTML = "Выполняется анализ…";
  errorBox.hidden = true;
  document.getElementById("resultStatus").textContent = "Обработка";
  try {
    const response = await fetch("/process", { method: "POST", body: data });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Не удалось обработать файл");
    document.getElementById("emptyState").hidden = true;
    const image = document.getElementById("resultImage");
    image.src = result.result_url + "?t=" + Date.now();
    image.hidden = false;
    document.getElementById("stats").hidden = false;
    document.getElementById("vehicleCount").textContent = result.vehicle_count;
    document.getElementById("occupiedCount").textContent = `${result.occupied_slots}/${result.total_slots}`;
    document.getElementById("freeCount").textContent = result.free_slots;
    document.getElementById("confidence").textContent = result.mean_confidence ? (result.mean_confidence * 100).toFixed(1) + "%" : "—";
    const note = document.getElementById("resultNote");
    note.textContent = result.note;
    note.hidden = false;
    document.getElementById("resultStatus").textContent = "Анализ завершён";
    setTimeout(() => location.reload(), 1500);
  } catch (error) {
    errorBox.textContent = error.message;
    errorBox.hidden = false;
    document.getElementById("resultStatus").textContent = "Ошибка";
  } finally {
    runButton.disabled = false;
    runButton.innerHTML = 'Запустить анализ <span>→</span>';
  }
});
