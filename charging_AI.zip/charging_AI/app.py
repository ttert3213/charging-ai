from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_from_directory, redirect, url_for, flash
from werkzeug.utils import secure_filename
from detector import VehicleDetector, DetectionError
from database import init_db, add_record, get_recent, get_record, get_db_path
from reports import create_pdf_report
import uuid
import os

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
RESULT_DIR = BASE_DIR / "results"
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}
MAX_CONTENT_LENGTH = 20 * 1024 * 1024

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-key-for-local-use")
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

UPLOAD_DIR.mkdir(exist_ok=True)
RESULT_DIR.mkdir(exist_ok=True)
init_db()

detector = None

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def get_detector():
    global detector
    if detector is None:
        detector = VehicleDetector()
    return detector

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", records=get_recent(10))

@app.route("/process", methods=["POST"])
def process():
    if "image" not in request.files:
        return jsonify({"error": "Файл изображения не передан"}), 400
    file = request.files["image"]
    if not file or file.filename == "":
        return jsonify({"error": "Выберите изображение"}), 400
    if not allowed_file(file.filename):
        return jsonify({"error": "Поддерживаются JPG, JPEG, PNG и WEBP"}), 400

    safe_name = secure_filename(file.filename)
    ext = safe_name.rsplit(".", 1)[1].lower()
    token = uuid.uuid4().hex
    input_path = UPLOAD_DIR / f"{token}.{ext}"
    output_name = f"{token}_result.jpg"
    output_path = RESULT_DIR / output_name
    file.save(input_path)

    try:
        result = get_detector().analyze(input_path, output_path)
        record_id = add_record(
            source_name=safe_name,
            result_name=output_name,
            vehicle_count=result["vehicle_count"],
            occupied_slots=result["occupied_slots"],
            total_slots=result["total_slots"],
            confidence=result["mean_confidence"],
        )
        result.update({
            "record_id": record_id,
            "result_url": url_for("result_file", filename=output_name),
            "source_name": safe_name,
        })
        return jsonify(result)
    except DetectionError as exc:
        input_path.unlink(missing_ok=True)
        return jsonify({"error": str(exc)}), 422
    except Exception as exc:
        app.logger.exception("Ошибка обработки изображения")
        input_path.unlink(missing_ok=True)
        return jsonify({"error": f"Внутренняя ошибка обработки: {exc}"}), 500

@app.route("/results/<path:filename>")
def result_file(filename):
    return send_from_directory(RESULT_DIR, filename)

@app.route("/history")
def history():
    return render_template("history.html", records=get_recent(100))

@app.route("/report.pdf")
def pdf_report():
    path = create_pdf_report(get_recent(100))
    return send_from_directory(path.parent, path.name, as_attachment=True)

@app.route("/api/history/<int:record_id>")
def history_item(record_id):
    record = get_record(record_id)
    if not record:
        return jsonify({"error": "Запись не найдена"}), 404
    return jsonify(record)

@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": "Файл превышает допустимый размер 20 МБ"}), 413

if __name__ == "__main__":
    # Для локального учебного запуска. Не использовать встроенный сервер Flask в production.
    app.run(host="127.0.0.1", port=5000, debug=True)
